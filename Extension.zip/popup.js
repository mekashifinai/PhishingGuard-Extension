// PhishingGuard Popup script

document.addEventListener('DOMContentLoaded', async () => {
  // UI Elements
  const appContainer = document.getElementById('appContainer');
  const themeToggleBtn = document.getElementById('themeToggleBtn');
  const settingsToggleBtn = document.getElementById('settingsToggleBtn');
  const settingsPanel = document.getElementById('settingsPanel');
  
  const urlText = document.getElementById('urlText');
  const scoreRing = document.getElementById('scoreRing');
  const scoreRingSvg = document.querySelector('.score-ring');
  const scoreNumber = document.getElementById('scoreNumber');
  const statusBadge = document.getElementById('statusBadge');
  const detectionMethod = document.getElementById('detectionMethod');
  const serverScoreText = document.getElementById('serverScoreText');
  const reasonsSection = document.getElementById('reasonsSection');
  const reasonsList = document.getElementById('reasonsList');
  
  // Server Metadata Elements
  const metaIp = document.getElementById('metaIp');
  const metaIsp = document.getElementById('metaIsp');
  const metaLoc = document.getElementById('metaLoc');
  const metaRegistrar = document.getElementById('metaRegistrar');
  const metaCreated = document.getElementById('metaCreated');
  const serverMetaRows = document.querySelectorAll('.server-meta-row');
  
  // Header Server Status
  const serverStatusPill = document.getElementById('serverStatusPill');
  const serverStatusDot = document.getElementById('serverStatusDot');
  const serverStatusText = document.getElementById('serverStatusText');
  
  // Toggles
  const serverAiToggle = document.getElementById('serverAiToggle');
  const autoBlockToggle = document.getElementById('autoBlockToggle');
  
  // Buttons
  const reanalyzeBtn = document.getElementById('reanalyzeBtn');
  const openLogsBtn = document.getElementById('openLogsBtn');

  const RING_CIRCUMFERENCE = 314.16;
  let currentTab = null;

  // Toggle Settings Panel (Gear Icon)
  settingsToggleBtn.addEventListener('click', () => {
    const isCollapsed = settingsPanel.classList.toggle('collapsed');
    settingsToggleBtn.style.transform = isCollapsed ? 'rotate(0deg)' : 'rotate(45deg)';
  });

  // Load and apply settings
  const { settings } = await chrome.storage.local.get('settings');
  const activeSettings = settings || {
    localAiEnabled: true,
    serverAiEnabled: true,
    autoBlockEnabled: true,
    darkMode: true,
    serverUrl: "https://mekashif-phishingguard-backend.hf.space"
  };

  // Set initial toggles UI
  serverAiToggle.checked = activeSettings.serverAiEnabled;
  autoBlockToggle.checked = activeSettings.autoBlockEnabled;
  
  // Apply dark mode
  if (activeSettings.darkMode) {
    document.body.classList.add('dark-mode');
    themeToggleBtn.innerText = "🌙";
  } else {
    document.body.classList.remove('dark-mode');
    themeToggleBtn.innerText = "☀️";
  }

  // Handle Theme Toggle
  themeToggleBtn.addEventListener('click', async () => {
    const isDark = document.body.classList.toggle('dark-mode');
    themeToggleBtn.innerText = isDark ? "🌙" : "☀️";
    
    const currentSettings = (await chrome.storage.local.get('settings')).settings || activeSettings;
    currentSettings.darkMode = isDark;
    await chrome.storage.local.set({ settings: currentSettings });
  });

  // Handle Controls Toggles
  const saveToggleState = async () => {
    const currentSettings = (await chrome.storage.local.get('settings')).settings || activeSettings;
    currentSettings.localHeuristicsEnabled = true; // Always enabled for offline fallback
    currentSettings.serverAiEnabled = serverAiToggle.checked;
    currentSettings.autoBlockEnabled = autoBlockToggle.checked;
    await chrome.storage.local.set({ settings: currentSettings });
    
    if (currentTab) {
      triggerReScan();
    }
  };

  serverAiToggle.addEventListener('change', saveToggleState);
  autoBlockToggle.addEventListener('change', saveToggleState);

  function updateServerTooltip(activeUrl, lastError) {
    const defaultUrl = activeSettings.serverUrl;
    const tooltipText = `API URL: ${activeUrl || defaultUrl}\n` + 
                        (lastError ? `Last Error: ${lastError}` : `Status: Online`);
    serverStatusPill.title = tooltipText;
  }

  // Initialize Header Connection Dot instantly from storage
  function renderServerStatusDot(isOnline, stage = "final") {
    if (!serverAiToggle.checked) {
      serverStatusDot.className = "status-dot";
      serverStatusText.innerText = "Disabled";
      return;
    }

    if (stage === "server_checking") {
      serverStatusDot.className = "status-dot loading";
      serverStatusText.innerText = "Verifying...";
    } else {
      if (isOnline) {
        serverStatusDot.className = "status-dot online";
        serverStatusText.innerText = "Online";
      } else {
        serverStatusDot.className = "status-dot offline";
        serverStatusText.innerText = "Offline";
      }
    }
  }

  // Initial load of server connection status (checking if a check is in progress)
  chrome.storage.local.get(['serverOnline', 'activeServerUrl', 'lastConnectionError', 'isCheckingConnection'], (res) => {
    if (res.isCheckingConnection && serverAiToggle.checked) {
      serverStatusDot.className = "status-dot loading";
      serverStatusText.innerText = "Connecting...";
    } else {
      renderServerStatusDot(!!res.serverOnline);
    }
    updateServerTooltip(res.activeServerUrl, res.lastConnectionError);
  });

  // Verify server connection in background on popup open
  if (activeSettings.serverAiEnabled) {
    chrome.runtime.sendMessage({ action: "verifyConnection" }, (response) => {
      if (chrome.runtime.lastError) return;
      if (response) {
        renderServerStatusDot(response.serverOnline);
      }
    });
  }

  // Load Active Tab and its Analysis State
  async function loadActiveTabInfo() {
    const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
    if (tabs.length === 0) return;
    
    currentTab = tabs[0];
    const urlStr = currentTab.url;

    if (!urlStr || (!urlStr.startsWith('http://') && !urlStr.startsWith('https://'))) {
      urlText.innerText = "System Page";
      scoreNumber.innerText = "--";
      
      // Reset the ring completely (empty and neutral color)
      scoreRing.classList.remove('checking');
      scoreRingSvg.classList.remove('checking');
      scoreRing.style.strokeDasharray = `${RING_CIRCUMFERENCE}`;
      scoreRing.style.strokeDashoffset = RING_CIRCUMFERENCE; // Empty ring
      scoreRing.style.stroke = "var(--border-color)";
      
      statusBadge.innerText = "BYPASSED";
      statusBadge.className = "badge";
      statusBadge.style.backgroundColor = "var(--border-color)";
      statusBadge.style.color = "var(--text-muted)";
      
      detectionMethod.innerText = "Internal Browser Page";
      serverScoreText.innerText = "N/A";
      serverStatusDot.className = "status-dot";
      serverStatusText.innerText = "Not Active";
      reanalyzeBtn.disabled = true;
      
      // Hide metadata and reasons section
      serverMetaRows.forEach(row => {
        row.style.display = 'none';
      });
      reasonsSection.style.display = 'none';
      return;
    }

    try {
      const parsedUrl = new URL(urlStr);
      urlText.innerText = parsedUrl.hostname + parsedUrl.pathname;
      urlText.title = urlStr;
    } catch (e) {
      urlText.innerText = urlStr;
    }

    const tabKey = `tab_${currentTab.id}`;
    const dataObj = await chrome.storage.local.get(tabKey);
    const result = dataObj[tabKey];

    if (result) {
      renderAnalysisResult(result);
    } else {
      triggerReScan();
    }
  }

  // Update UI Elements based on scan results
  function renderAnalysisResult(result) {
    const score = result.score;
    const status = result.status; 
    const stage = result.stage || "final"; // preliminary, server_checking, final

    scoreNumber.innerText = score !== null ? score : "--";
    
    // Status Badge
    if (stage === "server_checking") {
      statusBadge.innerText = "VERIFYING...";
      statusBadge.className = "badge warning";
    } else {
      statusBadge.innerText = status;
      statusBadge.className = `badge ${status.toLowerCase()}`;
    }

    updateRing(score, status, stage);

    // Breakdown details
    detectionMethod.innerText = result.detection;
    serverScoreText.innerText = result.serverScore !== null ? `${result.serverScore}%` : "Disabled";

    // Render Suspicion Indicators / Reasons
    if (result.reasons && result.reasons.length > 0 && stage === "final") {
      reasonsList.innerHTML = '';
      result.reasons.forEach(reason => {
        const li = document.createElement('li');
        li.innerText = reason;
        reasonsList.appendChild(li);
      });
      reasonsSection.style.display = 'block';
    } else {
      reasonsSection.style.display = 'none';
      reasonsList.innerHTML = '';
    }

    // Set connection status based on result feedback and stage
    if (stage === "server_checking") {
      renderServerStatusDot(false, "server_checking");
    } else {
      chrome.storage.local.get('serverOnline', (res) => {
        renderServerStatusDot(!!res.serverOnline);
      });
    }

    // Render Server Metadata if available and stage is final (hiding individual rows if missing)
    if (result.metadata && stage === "final") {
      const meta = result.metadata;
      
      // IP Address
      if (meta.ip && meta.ip !== "N/A") {
        metaIp.innerText = meta.ip;
        metaIp.closest('.server-meta-row').style.display = 'flex';
      } else {
        metaIp.closest('.server-meta-row').style.display = 'none';
      }
      
      // ISP / Host
      if (meta.isp && meta.isp !== "N/A") {
        metaIsp.innerText = meta.isp;
        metaIsp.closest('.server-meta-row').style.display = 'flex';
      } else {
        metaIsp.closest('.server-meta-row').style.display = 'none';
      }
      
      // Location (Country + City)
      if (meta.country && meta.country !== "N/A") {
        metaLoc.innerText = meta.city && meta.city !== "N/A" ? `${meta.city}, ${meta.country}` : meta.country;
        metaLoc.closest('.server-meta-row').style.display = 'flex';
      } else {
        metaLoc.closest('.server-meta-row').style.display = 'none';
      }
      
      // Domain Registrar
      if (meta.registrar && meta.registrar !== "N/A") {
        metaRegistrar.innerText = meta.registrar;
        metaRegistrar.closest('.server-meta-row').style.display = 'flex';
      } else {
        metaRegistrar.closest('.server-meta-row').style.display = 'none';
      }
      
      // Created Date
      if (meta.created_date && meta.created_date !== "N/A") {
        metaCreated.innerText = meta.created_date;
        metaCreated.closest('.server-meta-row').style.display = 'flex';
      } else {
        metaCreated.closest('.server-meta-row').style.display = 'none';
      }
    } else {
      serverMetaRows.forEach(row => {
        row.style.display = 'none';
      });
    }
  }

  // Set circle stroke and color
  function updateRing(score, status, stage) {
    if (stage === "server_checking") {
      scoreRing.classList.add('checking');
      scoreRingSvg.classList.add('checking');
      // Reset inline styles so CSS styles/animations can apply
      scoreRing.style.strokeDasharray = '';
      scoreRing.style.strokeDashoffset = '';
      scoreRing.style.stroke = '';
    } else {
      scoreRing.classList.remove('checking');
      scoreRingSvg.classList.remove('checking');
      
      const offset = RING_CIRCUMFERENCE - (score / 100) * RING_CIRCUMFERENCE;
      scoreRing.style.strokeDasharray = `${RING_CIRCUMFERENCE}`;
      scoreRing.style.strokeDashoffset = offset;

      if (status === "DANGEROUS") {
        scoreRing.style.stroke = "var(--danger-color)";
      } else if (status === "WARNING") {
        scoreRing.style.stroke = "var(--warn-color)";
      } else {
        scoreRing.style.stroke = "var(--safe-color)";
      }
    }
  }

  // Trigger page recheck
  function triggerReScan() {
    if (!currentTab) return;
    
    urlText.innerText = "Scanning website...";
    scoreNumber.innerText = "--";
    scoreRing.classList.add('checking');
    scoreRingSvg.classList.add('checking');
    statusBadge.innerText = "SCANNING";
    statusBadge.className = "badge";
    
    if (serverAiToggle.checked) {
      serverStatusDot.className = "status-dot loading";
      serverStatusText.innerText = "Connecting...";
    } else {
      serverStatusDot.className = "status-dot";
      serverStatusText.innerText = "Disabled";
    }

    chrome.runtime.sendMessage({
      action: "reAnalyze",
      url: currentTab.url,
      tabId: currentTab.id
    }, (response) => {
      if (response && response.data) {
        renderAnalysisResult(response.data);
      }
    });
  }

  // Listen for real-time background analysis updates
  chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "analysisUpdated" && currentTab && request.tabId === currentTab.id) {
      renderAnalysisResult(request.data);
    }
    
    if (request.action === "serverConnectionChecking") {
      serverStatusDot.className = "status-dot loading";
      serverStatusText.innerText = `Connecting... (${request.attempt}/${request.maxAttempts})`;
    }
    
    if (request.action === "serverConnectionUpdated") {
      renderServerStatusDot(request.serverOnline);
      chrome.storage.local.get(['activeServerUrl', 'lastConnectionError'], (res) => {
        updateServerTooltip(res.activeServerUrl, res.lastConnectionError);
      });
    }
  });

  // Event Listeners
  reanalyzeBtn.addEventListener('click', triggerReScan);
  openLogsBtn.addEventListener('click', () => {
    chrome.tabs.create({ url: chrome.runtime.getURL('logs.html') });
  });

  // Load tab info on load
  await loadActiveTabInfo();
});
