// PhishingGuard Content Script
// Displays an Apple-like warning banner for moderate risk websites

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "showWarningBanner") {
    showBanner(request.score);
    sendResponse({ status: "banner_displayed" });
  } else if (request.action === "showOfflineCautionBanner") {
    showOfflineCaution();
    sendResponse({ status: "caution_displayed" });
  }
  return true;
});

let hasAlertedOffline = false;

function showOfflineCaution() {
  if (hasAlertedOffline) return;
  hasAlertedOffline = true;
  // Use a tiny timeout to ensure it runs after the page finishes rendering so the alert box appears correctly
  setTimeout(() => {
    alert("PhishingGuard: Server not connected and site is not from the trusted list. Please exercise caution.");
  }, 100);
}


function showBanner(score) {
  if (document.getElementById("phishingguard-warning-banner")) return;

  const banner = document.createElement("div");
  banner.id = "phishingguard-warning-banner";
  banner.style.cssText = `
    position: fixed;
    top: 20px;
    left: 50%;
    transform: translateX(-50%) translateY(-150px);
    z-index: 2147483647;
    background: rgba(15, 23, 42, 0.9);
    backdrop-filter: blur(12px);
    -webkit-backdrop-filter: blur(12px);
    color: #ffffff;
    padding: 14px 28px;
    border-radius: 16px;
    box-shadow: 0 20px 40px rgba(0, 0, 0, 0.35), 0 0 0 1px rgba(255, 255, 255, 0.1);
    font-family: -apple-system, BlinkMacSystemFont, "SF Pro Text", "SF Pro Display", "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
    font-size: 13.5px;
    font-weight: 500;
    display: flex;
    align-items: center;
    gap: 16px;
    transition: transform 0.6s cubic-bezier(0.16, 1, 0.3, 1);
    border: 1px solid rgba(250, 204, 21, 0.3);
  `;

  const icon = document.createElement("div");
  icon.innerHTML = "⚠️";
  icon.style.cssText = `
    font-size: 18px;
    animation: pulse 2s infinite ease-in-out;
  `;

  const text = document.createElement("div");
  text.style.color = "#f3f4f6";
  text.innerHTML = `PhishingGuard: This page is flagged as a <strong>Warning</strong> (Risk Score: <span style="color: #facc15; font-weight: 700;">${score}%</span>).`;

  const dismissBtn = document.createElement("button");
  dismissBtn.innerText = "Dismiss";
  dismissBtn.style.cssText = `
    background: rgba(255, 255, 255, 0.12);
    border: none;
    color: #ffffff;
    padding: 6px 14px;
    border-radius: 10px;
    cursor: pointer;
    font-weight: 600;
    font-size: 12px;
    font-family: inherit;
    transition: all 0.2s ease;
    outline: none;
  `;
  dismissBtn.onmouseenter = () => {
    dismissBtn.style.background = "rgba(255, 255, 255, 0.2)";
    dismissBtn.style.transform = "scale(1.02)";
  };
  dismissBtn.onmouseleave = () => {
    dismissBtn.style.background = "rgba(255, 255, 255, 0.12)";
    dismissBtn.style.transform = "scale(1)";
  };
  dismissBtn.onclick = () => {
    banner.style.transform = "translateX(-50%) translateY(-150px)";
    setTimeout(() => banner.remove(), 600);
  };

  // Add styles for the pulse animation if not exists
  if (!document.getElementById("phishingguard-keyframes")) {
    const styleSheet = document.createElement("style");
    styleSheet.id = "phishingguard-keyframes";
    styleSheet.innerText = `
      @keyframes pulse {
        0%, 100% { opacity: 1; transform: scale(1); }
        50% { opacity: 0.7; transform: scale(1.1); }
      }
    `;
    document.head.appendChild(styleSheet);
  }

  banner.appendChild(icon);
  banner.appendChild(text);
  banner.appendChild(dismissBtn);
  document.body.appendChild(banner);

  // Trigger smooth enter slide-in
  requestAnimationFrame(() => {
    setTimeout(() => {
      banner.style.transform = "translateX(-50%) translateY(0)";
    }, 100);
  });
}

// Query status on initial page load to prevent race conditions during load
try {
  chrome.runtime.sendMessage({ action: "checkPageStatus" }, (response) => {
    if (chrome.runtime.lastError) return;
    if (response) {
      if (response.status === "warning") {
        showBanner(response.score);
      } else if (response.status === "offline_caution") {
        showOfflineCaution();
      }
    }
  });
} catch (e) {
  console.warn("PhishingGuard: Error sending checkPageStatus message:", e);
}
