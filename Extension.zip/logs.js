// PhishingGuard Logs Dashboard Script

document.addEventListener('DOMContentLoaded', async () => {
  const logsTableBody = document.getElementById('logsTableBody');
  const emptyState = document.getElementById('emptyState');
  const logsTable = document.getElementById('logsTable');
  const themeToggleBtn = document.getElementById('themeToggleBtn');
  const filterPills = document.querySelectorAll('.filter-pill');
  
  // Action Buttons
  const clearBtn = document.getElementById('clearBtn');
  const exportJsonBtn = document.getElementById('exportJsonBtn');
  const exportCsvBtn = document.getElementById('exportCsvBtn');
  const exportTxtBtn = document.getElementById('exportTxtBtn');

  let allLogs = [];
  let currentFilter = 'all';

  // Theme Sync
  const { settings } = await chrome.storage.local.get('settings');
  const activeSettings = settings || { darkMode: true };
  
  const applyTheme = (isDark) => {
    if (isDark) {
      document.body.classList.remove('light-mode');
      themeToggleBtn.innerText = "🌙 Toggle Dark Mode";
    } else {
      document.body.classList.add('light-mode');
      themeToggleBtn.innerText = "☀️ Toggle Light Mode";
    }
  };
  
  applyTheme(activeSettings.darkMode);

  themeToggleBtn.addEventListener('click', async () => {
    const isDarkNow = !document.body.classList.contains('light-mode');
    applyTheme(!isDarkNow);
    
    // Save theme
    const currentSettings = (await chrome.storage.local.get('settings')).settings || activeSettings;
    currentSettings.darkMode = !isDarkNow;
    await chrome.storage.local.set({ settings: currentSettings });
  });

  // Load logs
  async function loadLogs() {
    const data = await chrome.storage.local.get('logs');
    allLogs = data.logs || [];
    renderLogs();
  }

  // Render logs based on current filter
  function renderLogs() {
    logsTableBody.innerHTML = '';
    
    const filteredLogs = allLogs.filter(log => {
      if (currentFilter === 'all') return true;
      if (currentFilter === 'safe') return log.status === 'SAFE';
      if (currentFilter === 'warning') return log.status === 'WARNING';
      if (currentFilter === 'dangerous') return log.status === 'DANGEROUS';
      return true;
    });

    if (filteredLogs.length === 0) {
      logsTable.style.display = 'none';
      emptyState.style.display = 'block';
      return;
    }

    logsTable.style.display = 'table';
    emptyState.style.display = 'none';

    filteredLogs.forEach(log => {
      const row = document.createElement('tr');
      row.className = 'log-row';
      
      // Expand Button column
      const tdExpand = document.createElement('td');
      tdExpand.className = 'td-expand-btn';
      tdExpand.innerText = '▶';
      row.appendChild(tdExpand);
      
      // Timestamp
      const tdTime = document.createElement('td');
      tdTime.className = 'td-time';
      tdTime.innerText = new Date(log.timestamp).toLocaleString();
      row.appendChild(tdTime);
      
      // URL
      const tdUrl = document.createElement('td');
      tdUrl.className = 'td-url';
      const urlLink = document.createElement('a');
      urlLink.href = log.url;
      urlLink.target = '_blank';
      urlLink.innerText = log.url;
      urlLink.addEventListener('click', (e) => {
        e.stopPropagation(); // Prevent toggling the dropdown on link click
      });
      tdUrl.appendChild(urlLink);
      row.appendChild(tdUrl);

      // Score
      const tdScore = document.createElement('td');
      const scoreBadge = document.createElement('span');
      scoreBadge.className = `score-badge ${getBadgeClass(log.status)}`;
      scoreBadge.innerText = `${log.score}%`;
      tdScore.appendChild(scoreBadge);
      row.appendChild(tdScore);

      // Status
      const tdStatus = document.createElement('td');
      const statusSpan = document.createElement('span');
      statusSpan.className = `status-text ${log.status.toLowerCase()}`;
      statusSpan.innerText = log.status === 'DANGEROUS' ? 'BLOCKED' : log.status;
      tdStatus.appendChild(statusSpan);
      row.appendChild(tdStatus);

      // Detection
      const tdMethod = document.createElement('td');
      tdMethod.innerText = log.detection;
      row.appendChild(tdMethod);
      
      // Collapsible details row
      const detailsRow = document.createElement('tr');
      detailsRow.className = 'details-row';
      detailsRow.style.display = 'none';
      
      const tdDetails = document.createElement('td');
      tdDetails.setAttribute('colspan', '6');
      
      const detailsContent = document.createElement('div');
      detailsContent.className = 'details-content';
      
      // Left Column: Suspicion Indicators
      const colLeft = document.createElement('div');
      colLeft.className = 'details-column';
      const leftTitle = document.createElement('h4');
      leftTitle.innerText = "Suspicion Analysis";
      colLeft.appendChild(leftTitle);
      
      const reasonsList = document.createElement('ul');
      reasonsList.className = 'details-reasons-list';
      if (log.reasons && log.reasons.length > 0) {
        log.reasons.forEach(r => {
          const li = document.createElement('li');
          li.innerText = r;
          reasonsList.appendChild(li);
        });
      } else {
        const li = document.createElement('li');
        li.innerText = "No specific suspicion indicators detected.";
        reasonsList.appendChild(li);
      }
      colLeft.appendChild(reasonsList);
      
      // Right Column: Domain Metadata
      const colRight = document.createElement('div');
      colRight.className = 'details-column';
      const rightTitle = document.createElement('h4');
      rightTitle.innerText = "Domain & Session Metadata";
      colRight.appendChild(rightTitle);
      
      const metaGrid = document.createElement('div');
      metaGrid.className = 'meta-grid';
      
      const addMetaField = (label, val) => {
        const lblNode = document.createElement('div');
        lblNode.className = 'meta-label';
        lblNode.innerText = label;
        
        const valNode = document.createElement('div');
        valNode.className = 'meta-value';
        valNode.innerText = val && val !== "N/A" ? val : "--";
        
        metaGrid.appendChild(lblNode);
        metaGrid.appendChild(valNode);
      };
      
      // Visited & Exited Times
      const vDate = new Date(log.timestamp);
      addMetaField("Visited At:", vDate.toLocaleString());
      if (log.exitedTime) {
        const eDate = new Date(log.exitedTime);
        addMetaField("Exited At:", eDate.toLocaleString());
        const diffMs = eDate - vDate;
        const diffSec = Math.floor(diffMs / 1000);
        let dur = "";
        if (diffSec < 60) {
          dur = `${diffSec}s`;
        } else {
          dur = `${Math.floor(diffSec / 60)}m ${diffSec % 60}s`;
        }
        addMetaField("Time Spent:", dur);
      } else {
        addMetaField("Exited At:", "Active / Open");
      }
      
      if (log.metadata) {
        const meta = log.metadata;
        addMetaField("IP Address:", meta.ip);
        addMetaField("ISP / Host:", meta.isp);
        addMetaField("Location:", meta.country && meta.country !== "N/A" ? (meta.city && meta.city !== "N/A" ? `${meta.city}, ${meta.country}` : meta.country) : "N/A");
        addMetaField("Registrar:", meta.registrar);
        addMetaField("Created Date:", meta.created_date);
      } else {
        const lblNode = document.createElement('div');
        lblNode.className = 'meta-label';
        lblNode.style.gridColumn = "span 2";
        lblNode.style.marginTop = "6px";
        lblNode.style.borderTop = "1px dashed rgba(255, 255, 255, 0.1)";
        lblNode.style.paddingTop = "6px";
        
        if (log.detection && log.detection.includes("Whitelist")) {
          lblNode.innerText = "Trusted whitelist domain (Metadata bypassed).";
        } else if (log.detection && log.detection.includes("Local Network")) {
          lblNode.innerText = "Internal Private Network IP.";
        } else {
          lblNode.innerText = "Offline Heuristics Fallback (No server metadata).";
        }
        metaGrid.appendChild(lblNode);
      }
      colRight.appendChild(metaGrid);
      
      detailsContent.appendChild(colLeft);
      detailsContent.appendChild(colRight);
      
      tdDetails.appendChild(detailsContent);
      detailsRow.appendChild(tdDetails);
      
      // Click event for expand/collapse on the row
      row.addEventListener('click', () => {
        const isExpanded = row.classList.toggle('expanded');
        detailsRow.style.display = isExpanded ? 'table-row' : 'none';
      });
      
      logsTableBody.appendChild(row);
      logsTableBody.appendChild(detailsRow);
    });
  }

  function getBadgeClass(status) {
    if (status === 'DANGEROUS') return 'danger';
    if (status === 'WARNING') return 'warn';
    return 'safe';
  }

  // Filter selection
  filterPills.forEach(pill => {
    pill.addEventListener('click', (e) => {
      filterPills.forEach(p => p.classList.remove('active'));
      e.target.classList.add('active');
      currentFilter = e.target.getAttribute('data-filter');
      renderLogs();
    });
  });

  // Clear Logs
  clearBtn.addEventListener('click', async () => {
    if (confirm("Are you sure you want to permanently delete all scan logs? This cannot be undone.")) {
      await chrome.storage.local.set({ logs: [] });
      allLogs = [];
      renderLogs();
    }
  });

  // Helper function to trigger download
  function downloadFile(content, fileName, contentType) {
    const blob = new Blob([content], { type: contentType });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = fileName;
    a.click();
    URL.revokeObjectURL(url);
  }

  // Export JSON
  exportJsonBtn.addEventListener('click', () => {
    if (allLogs.length === 0) return alert("No logs available to export.");
    const jsonStr = JSON.stringify(allLogs, null, 2);
    downloadFile(jsonStr, 'phishingguard_logs.json', 'application/json');
  });

  // Export CSV
  exportCsvBtn.addEventListener('click', () => {
    if (allLogs.length === 0) return alert("No logs available to export.");
    
    // Headers
    let csvContent = "Index,URL,Visited At,Exited At,Risk Score (%),Status,Detection Method,Suspicion Reasons,IP Address,ISP/Host,Location,Registrar,Created Date\n";
    
    // Rows
    allLogs.forEach((log, index) => {
      const visited = new Date(log.timestamp).toISOString();
      const exited = log.exitedTime ? new Date(log.exitedTime).toISOString() : "Active / Still Open";
      const url = `"${log.url.replace(/"/g, '""')}"`;
      const score = log.score;
      const status = log.status === 'DANGEROUS' ? 'BLOCKED' : log.status;
      const method = `"${log.detection.replace(/"/g, '""')}"`;
      const reasons = `"${(log.reasons || []).join('; ').replace(/"/g, '""')}"`;
      
      let ip = "N/A", isp = "N/A", loc = "N/A", reg = "N/A", created = "N/A";
      if (log.metadata) {
        ip = log.metadata.ip || "N/A";
        isp = log.metadata.isp || "N/A";
        loc = log.metadata.country && log.metadata.country !== "N/A" ? (log.metadata.city && log.metadata.city !== "N/A" ? `${log.metadata.city}, ${log.metadata.country}` : log.metadata.country) : "N/A";
        reg = log.metadata.registrar || "N/A";
        created = log.metadata.created_date || "N/A";
      }
      
      csvContent += `${index + 1},${url},${visited},${exited},${score},${status},${method},${reasons},"${ip.replace(/"/g, '""')}","${isp.replace(/"/g, '""')}","${loc.replace(/"/g, '""')}","${reg.replace(/"/g, '""')}","${created.replace(/"/g, '""')}"\n`;
    });
    
    downloadFile(csvContent, 'phishingguard_logs.csv', 'text/csv');
  });

  // Export Structured TXT file
  exportTxtBtn.addEventListener('click', () => {
    if (allLogs.length === 0) return alert("No logs available to export.");
    
    let txtContent = "==================================================\n";
    txtContent += "         PHISHINGGUARD AI - SECURITY LOGS\n";
    txtContent += "==================================================\n\n";
    
    allLogs.forEach((log, index) => {
      const vDate = new Date(log.timestamp);
      const visitedStr = vDate.toLocaleString();
      
      let exitedStr = "Active / Still Open";
      let durationStr = "N/A";
      if (log.exitedTime) {
        const eDate = new Date(log.exitedTime);
        exitedStr = eDate.toLocaleString();
        const diffMs = eDate - vDate;
        const diffSec = Math.floor(diffMs / 1000);
        if (diffSec < 60) {
          durationStr = `${diffSec} seconds`;
        } else {
          const diffMin = Math.floor(diffSec / 60);
          durationStr = `${diffMin} minute(s) and ${diffSec % 60} second(s)`;
        }
      }

      txtContent += `[Log Entry #${index + 1}]\n`;
      txtContent += `URL: ${log.url}\n`;
      txtContent += `Visited At: ${visitedStr}\n`;
      txtContent += `Exited At: ${exitedStr}\n`;
      txtContent += `Time Spent: ${durationStr}\n`;
      txtContent += `Risk Score: ${log.score}%\n`;
      txtContent += `Status: ${log.status === 'DANGEROUS' ? 'BLOCKED' : log.status}\n`;
      txtContent += `Detection Method: ${log.detection}\n`;
      
      // Suspicion Reasons
      txtContent += `Suspicion Analysis:\n`;
      if (log.reasons && log.reasons.length > 0) {
        log.reasons.forEach(r => {
          txtContent += `  - ${r}\n`;
        });
      } else {
        txtContent += `  - Clean URL structure\n`;
      }
      
      // Metadata
      txtContent += `Domain & Network Metadata:\n`;
      if (log.metadata) {
        const m = log.metadata;
        txtContent += `  - IP Address: ${m.ip || "N/A"}\n`;
        txtContent += `  - ISP / Host: ${m.isp || "N/A"}\n`;
        txtContent += `  - Location: ${m.country && m.country !== "N/A" ? (m.city && m.city !== "N/A" ? `${m.city}, ${m.country}` : m.country) : "N/A"}\n`;
        txtContent += `  - Registrar: ${m.registrar || "N/A"}\n`;
        txtContent += `  - Created Date: ${m.created_date || "N/A"}\n`;
      } else {
        txtContent += `  - No server metadata available (Offline Heuristics or Whitelist)\n`;
      }
      
      txtContent += `--------------------------------------------------\n\n`;
    });
    
    downloadFile(txtContent, 'phishingguard_logs.txt', 'text/plain');
  });

  // Listen for real-time background updates to logs (like exit times)
  chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "logsUpdated") {
      loadLogs();
    }
  });

  // Load on start
  await loadLogs();
});
