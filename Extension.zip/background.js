// PhishingGuard Background Script (Manifest V3 Service Worker)

// Constants
const DEFAULT_SETTINGS = {
  localHeuristicsEnabled: true,
  serverAiEnabled: true,
  autoBlockEnabled: true,
  darkMode: true,
  serverUrl: "https://mekashif-phishingguard-backend.hf.space"
};

// Global state
let trustedDomains = {};
let bypassedUrls = new Set();
let isServerOnline = false;
let activeTabUrls = {}; // tabId -> { url: urlStr, startTime: timestamp }

// Helper to normalize Hugging Face Space URL formats (web page URL -> direct API URL)
function normalizeServerUrl(urlStr) {
  if (!urlStr) return "";
  
  let cleanUrl = urlStr.trim();
  
  // Remove trailing slashes
  while (cleanUrl.endsWith('/')) {
    cleanUrl = cleanUrl.slice(0, -1);
  }
  
  // Strip common sub-paths if present
  if (cleanUrl.toLowerCase().endsWith('/analyze')) {
    cleanUrl = cleanUrl.slice(0, -8);
  }
  if (cleanUrl.toLowerCase().endsWith('/telemetry')) {
    cleanUrl = cleanUrl.slice(0, -10);
  }
  
  // Check if it's a Hugging Face Space webpage URL
  const spaceRegex = /huggingface\.co\/spaces\/([^/]+)\/([^/]+)/i;
  const match = cleanUrl.match(spaceRegex);
  if (match) {
    const username = match[1].toLowerCase();
    const spacename = match[2].toLowerCase();
    return `https://${username}-${spacename}.hf.space`;
  }
  
  // Make sure it starts with http:// or https://
  if (!cleanUrl.toLowerCase().startsWith('http://') && !cleanUrl.toLowerCase().startsWith('https://')) {
    cleanUrl = 'https://' + cleanUrl;
  }
  
  return cleanUrl;
}

// Startup connection verification with 3 retries
async function checkServerConnection(retries = 3, delay = 1000) {
  const { settings } = await chrome.storage.local.get('settings');
  const activeSettings = settings || DEFAULT_SETTINGS;
  
  if (!activeSettings.serverAiEnabled) {
    console.log("PhishingGuard: Server AI is disabled. Skipping connection check.");
    isServerOnline = false;
    await chrome.storage.local.set({ 
      serverOnline: false,
      isCheckingConnection: false
    });
    chrome.runtime.sendMessage({
      action: "serverConnectionUpdated",
      serverOnline: false
    }).catch(() => {});
    return false;
  }

  // Set connection checking state to true
  await chrome.storage.local.set({ isCheckingConnection: true });
  const serverUrl = normalizeServerUrl(activeSettings.serverUrl);
  const pingUrl = serverUrl.endsWith('/') ? serverUrl : `${serverUrl}/`;
  
  for (let i = 0; i < retries; i++) {
    try {
      console.log(`PhishingGuard: Checking server connection (Attempt ${i + 1}/${retries})...`);
      
      // Notify any active listeners of the connection check attempt
      chrome.runtime.sendMessage({
        action: "serverConnectionChecking",
        attempt: i + 1,
        maxAttempts: retries
      }).catch(() => {});

      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 4000); // 4 seconds timeout
      
      // Store the active URL we are checking
      await chrome.storage.local.set({ 
        activeServerUrl: pingUrl,
        lastConnectionAttempt: new Date().toISOString()
      });

      const response = await fetch(pingUrl, { 
        method: 'GET',
        signal: controller.signal
      });
      clearTimeout(timeoutId);
      
      if (response.ok) {
        isServerOnline = true;
        console.log("PhishingGuard: Server connection verified (Online).");
        await chrome.storage.local.set({ 
          serverOnline: true,
          isCheckingConnection: false,
          lastConnectionError: null,
          lastConnectionStatus: response.status
        });
        
        chrome.runtime.sendMessage({
          action: "serverConnectionUpdated",
          serverOnline: true
        }).catch(() => {});

        return true;
      } else {
        console.warn(`PhishingGuard: Server connection attempt ${i + 1} returned status: ${response.status}`);
        await chrome.storage.local.set({ 
          lastConnectionError: `HTTP Status ${response.status}`,
          lastConnectionStatus: response.status
        });
      }
    } catch (err) {
      console.warn(`PhishingGuard: Server connection attempt ${i + 1} failed:`, err);
      await chrome.storage.local.set({ 
        lastConnectionError: err.message || String(err),
        lastConnectionStatus: null
      });
    }
    
    if (i < retries - 1) {
      await new Promise(resolve => setTimeout(resolve, delay));
    }
  }
  
  isServerOnline = false;
  console.log(`PhishingGuard: Server connection failed after ${retries} tries (Offline).`);
  await chrome.storage.local.set({ 
    serverOnline: false,
    isCheckingConnection: false
  });
  
  chrome.runtime.sendMessage({
    action: "serverConnectionUpdated",
    serverOnline: false
  }).catch(() => {});

  return false;
}

// Initialize configuration and whitelists
async function initialize() {
  console.log("PhishingGuard: Initializing assets...");
  
  // Set default settings if not exists
  let { settings } = await chrome.storage.local.get('settings');
  if (!settings) {
    settings = DEFAULT_SETTINGS;
    await chrome.storage.local.set({ settings: DEFAULT_SETTINGS });
  } else {
    // If settings exists but has an outdated, truncated, or webpage serverUrl, force-update it
    const normalizedUrl = normalizeServerUrl(settings.serverUrl);
    if (!settings.serverUrl || 
        normalizedUrl !== settings.serverUrl ||
        settings.serverUrl.includes("idkas-phishingguard") || 
        settings.serverUrl.includes("mekashif-phishin") ||
        settings.serverUrl.length < 25) {
      settings.serverUrl = DEFAULT_SETTINGS.serverUrl;
      await chrome.storage.local.set({ settings: settings });
      console.log("PhishingGuard: Force-updated server URL in settings to:", DEFAULT_SETTINGS.serverUrl);
    }
    
    // Migrate settings: replace localAiEnabled with localHeuristicsEnabled
    if (settings.localAiEnabled !== undefined) {
      settings.localHeuristicsEnabled = settings.localAiEnabled;
      delete settings.localAiEnabled;
      await chrome.storage.local.set({ settings: settings });
    }
  }

  // Migration: Clear old tab cache and logs that might contain ONNX references
  try {
    const allStorage = await chrome.storage.local.get(null);
    const keysToRemove = Object.keys(allStorage).filter(key => key.startsWith('tab_'));
    if (keysToRemove.length > 0) {
      await chrome.storage.local.remove(keysToRemove);
      console.log(`PhishingGuard: Cleared ${keysToRemove.length} cached tab states.`);
    }
    
    if (allStorage.logs) {
      const cleanedLogs = allStorage.logs.map(log => {
        if (log.reasons) {
          log.reasons = log.reasons.map(r => r.replace(/onnx/gi, 'Heuristics'));
        }
        if (log.detection) {
          log.detection = log.detection.replace(/onnx/gi, 'Heuristics');
        }
        return log;
      });
      await chrome.storage.local.set({ logs: cleanedLogs });
      console.log("PhishingGuard: Cleaned ONNX references from logs.");
    }
  } catch (err) {
    console.error("PhishingGuard: Error running storage migrations:", err);
  }

  // Load Whitelist
  try {
    const trustedUrl = chrome.runtime.getURL('assets/trusted_domains.json');
    const trustedResponse = await fetch(trustedUrl);
    trustedDomains = await trustedResponse.json();
    console.log(`PhishingGuard: Loaded ${Object.keys(trustedDomains).length} trusted domains.`);
  } catch (err) {
    console.error("PhishingGuard: Error loading trusted_domains.json, using fallback", err);
    trustedDomains = { "google.com": true, "github.com": true, "wikipedia.org": true };
  }
}

// Call init on service worker start
chrome.runtime.onInstalled.addListener(() => {
  initialize().then(() => {
    checkServerConnection(3, 1000).catch(e => console.warn("Startup connection check failed:", e));
  });
});

chrome.runtime.onStartup.addListener(() => {
  initialize().then(() => {
    checkServerConnection(3, 1000).catch(e => console.warn("Startup connection check failed:", e));
  });
});

// Run asset initialization directly on import
initialize();

// Feature Extraction helper functions
function calculateEntropy(str) {
  if (!str) return 0;
  const frequencies = {};
  for (let char of str) {
    frequencies[char] = (frequencies[char] || 0) + 1;
  }
  let entropy = 0;
  const len = str.length;
  for (let char in frequencies) {
    const p = frequencies[char] / len;
    entropy -= p * Math.log2(p);
  }
  return entropy;
}

// Fast local rule-based heuristic scanner (runs instantly and functions offline)
function runLocalHeuristics(urlStr) {
  try {
    const url = new URL(urlStr);
    const hostname = url.hostname.toLowerCase();
    const urlLower = urlStr.toLowerCase();
    
    let score = 15; // Baseline safe score
    const reasons = [];

    // 1. Check if hostname is an IP address
    const ipv4Regex = /^(?:[0-9]{1,3}\.){3}[0-9]{1,3}$/;
    if (ipv4Regex.test(hostname) || hostname.includes(':')) {
      score += 40;
      reasons.push("Hostname is a raw IP address");
    }

    // 2. Check for user spoofing character '@'
    if (urlStr.includes('@')) {
      score += 30;
      reasons.push("URL contains '@' (user spoofing signature)");
    }

    // 3. Check for suspicious double slashes
    if (urlStr.split('//').slice(1).join('//').includes('//')) {
      score += 20;
      reasons.push("Path contains suspicious double slashes '//'");
    }

    // 4. Check for excessive dots
    const dotCount = (urlStr.match(/\./g) || []).length;
    if (dotCount > 4) {
      score += 15;
      reasons.push("Excessive subdomains/dots");
    }

    // 5. Check for excessive hyphens
    const hyphenCount = (urlStr.match(/-/g) || []).length;
    if (hyphenCount > 3) {
      score += 10;
      reasons.push("Excessive hyphens");
    }

    // 6. Check character entropy
    const entropy = calculateEntropy(urlStr);
    if (entropy > 4.5) {
      score += 15;
      reasons.push("High character entropy");
    }

    // 7. Check for keywords
    const keywords = ["login", "verify", "update", "secure", "account", "bank", "paypal", 
                      "amazon", "microsoft", "google", "signin", "confirm", "wallet", 
                      "support", "security", "password"];
    const matchedKeywords = keywords.filter(kw => urlLower.includes(kw));
    if (matchedKeywords.length > 0) {
      score += matchedKeywords.length * 15;
      reasons.push(`Contains suspicious keywords: ${matchedKeywords.join(', ')}`);
    }

    // 8. Brand spoofing check
    const TOP_BRANDS = ["paypal", "google", "microsoft", "apple", "amazon", "netflix", "facebook", "instagram", "twitter", "linkedin", "yahoo", "outlook", "hotmail", "gmail", "chase", "wellsfargo", "bankofamerica", "citibank"];
    for (const brand of TOP_BRANDS) {
      if (hostname.includes(brand)) {
        const isOfficial = hostname === brand + ".com" || hostname.endsWith("." + brand + ".com") ||
                           hostname === brand + ".co.uk" || hostname.endsWith("." + brand + ".co.uk") ||
                           checkIsWhitelisted(hostname);
        if (!isOfficial) {
          score += 35;
          reasons.push(`Potential brand spoofing (mimics ${brand})`);
          break;
        }
      }
    }

    // 9. High-risk TLD check
    const SUSPICIOUS_TLDS = ["xyz", "top", "fit", "gq", "cf", "ml", "tk", "ga", "work", "click", "buzz", "country", "info", "cc", "live"];
    const hostnameParts = hostname.split('.');
    const tld = hostnameParts[hostnameParts.length - 1];
    if (tld && SUSPICIOUS_TLDS.includes(tld)) {
      score += 15;
      reasons.push(`Uses a high-risk Top-Level Domain (.${tld})`);
    }

    // 10. Subdomain stacking check
    const cleanParts = hostnameParts.filter(p => p !== 'www');
    if (cleanParts.length > 3) {
      score += 15;
      reasons.push("Excessive subdomain nesting (stacking)");
    }

    score = Math.min(score, 100);
    return {
      score: score,
      reasons: reasons.length > 0 ? reasons : ["Clean URL structure (heuristics)"]
    };
  } catch (err) {
    console.error("PhishingGuard: Heuristic extraction failed:", err);
    return { score: 15, reasons: ["Failed to parse URL features"] };
  }
}

// Call server API for XGBoost
async function runServerInference(urlStr, serverUrl) {
  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 5000); // 5s timeout for stability

    const response = await fetch(`${serverUrl}/analyze`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ url: urlStr }),
      signal: controller.signal
    });
    
    clearTimeout(timeoutId);

    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }

    const data = await response.json();
    return {
      score: data.risk_score,
      reasons: data.reasons || [],
      metadata: data.metadata || null
    };
  } catch (err) {
    console.warn("PhishingGuard: Server inference failed or timed out", err);
    return null;
  }
}

// Send fire-and-forget telemetry for whitelisted domains
async function sendTelemetry(urlStr, serverUrl) {
  try {
    fetch(`${serverUrl}/telemetry`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ 
        url: urlStr, 
        domain: new URL(urlStr).hostname, 
        status: "trusted_bypass" 
      })
    }).catch(e => {});
  } catch (err) {}
}

// Broadcast updates to the popup dashboard
function broadcastState(tabId, state) {
  chrome.runtime.sendMessage({
    action: "analysisUpdated",
    tabId: tabId,
    data: state
  }).catch(e => {
    // Suppress error if popup is not open/listening
  });
}

function isLocalHostOrPrivateIp(hostname) {
  if (hostname === "localhost" || hostname === "127.0.0.1" || hostname.endsWith(".local")) {
    return true;
  }
  
  // Check private IPv4 ranges:
  // 127.0.0.0/8 (Loopback)
  // 10.0.0.0/8 (Private LAN)
  // 172.16.0.0/12 (Private LAN)
  // 192.168.0.0/16 (Private LAN)
  const parts = hostname.split('.');
  if (parts.length === 4) {
    const p1 = parseInt(parts[0], 10);
    const p2 = parseInt(parts[1], 10);
    if (!isNaN(p1) && !isNaN(p2)) {
      if (p1 === 127 || p1 === 10) return true;
      if (p1 === 192 && p2 === 168) return true;
      if (p1 === 172 && (p2 >= 16 && p2 <= 31)) return true;
    }
  }
  return false;
}

// Multi-user hosting platforms where subdomains should NOT be automatically trusted
const MULTI_USER_DOMAINS = new Set([
  "github.io",
  "vercel.app",
  "web.app",
  "firebaseapp.com",
  "herokuapp.com",
  "workers.dev",
  "pages.dev",
  "000webhostapp.com"
]);

// Helper to check if a domain is whitelisted (including subdomains of brand domains)
function checkIsWhitelisted(hostname) {
  if (!hostname) return false;
  
  // 1. Direct Match (e.g. "google.com" or "gemini.google.com" is directly in whitelist)
  if (trustedDomains[hostname]) {
    return true;
  }
  
  let cleanHostname = hostname;
  if (cleanHostname.startsWith("www.")) {
    cleanHostname = cleanHostname.substring(4);
  }
  
  if (trustedDomains[cleanHostname]) {
    return true;
  }

  // 2. Subdomain Match (e.g. "gemini.google.com" is a subdomain of "google.com")
  for (const trustedDomain of Object.keys(trustedDomains)) {
    // Skip multi-user hosting platforms
    if (MULTI_USER_DOMAINS.has(trustedDomain)) {
      continue;
    }
    
    if (cleanHostname.endsWith("." + trustedDomain)) {
      return true;
    }
  }

  return false;
}

// Main logic coordinator
async function analyzeUrl(urlStr, tabId) {
  if (!urlStr) return;
  
  // Filter out system schemas
  if (!urlStr.startsWith("http://") && !urlStr.startsWith("https://")) {
    chrome.action.setBadgeText({ tabId: tabId, text: "" }); // Clear badge text on system pages
    return;
  }

  // Skip if bypassed
  if (bypassedUrls.has(urlStr)) {
    updateBadge(tabId, 0, "SAFE");
    return;
  }

  const { settings } = await chrome.storage.local.get('settings');
  const activeSettings = settings || DEFAULT_SETTINGS;

  if (!activeSettings.localHeuristicsEnabled && !activeSettings.serverAiEnabled) {
    updateBadge(tabId, null, "SAFE");
    return;
  }

  let hostname = "";
  try {
    const parsed = new URL(urlStr);
    hostname = parsed.hostname.toLowerCase();
  } catch (e) {
    return;
  }

  // 1. Local Network / Private IP check (Home Router or Local Host)
  if (isLocalHostOrPrivateIp(hostname)) {
    console.log(`PhishingGuard: Local network bypass for ${hostname}`);
    const localResult = {
      url: urlStr,
      score: 0,
      status: "SAFE",
      detection: "Local Network Check",
      timestamp: new Date().toISOString(),
      reasons: ["Local Network Address (Home Router / Local Server)"],
      localScore: 0,
      serverScore: 0,
      serverConnected: isServerOnline,
      stage: "final",
      metadata: {
        ip: hostname,
        country: "Local Network",
        city: "Local",
        isp: "Private LAN",
        registrar: "Not Registered (Internal IP)",
        created_date: "N/A"
      }
    };

    await chrome.storage.local.set({ [`tab_${tabId}`]: localResult });
    await saveLog(localResult);
    updateBadge(tabId, 0, "SAFE"); // Show safe green badge
    broadcastState(tabId, localResult);
    return;
  }

  let cleanHostname = hostname;
  if (cleanHostname.startsWith("www.")) {
    cleanHostname = cleanHostname.substring(4);
  }

  // Whitelist Check
  const isWhitelisted = checkIsWhitelisted(hostname);
  if (isWhitelisted) {
    console.log(`PhishingGuard: Whitelist hit for ${hostname}.`);
    
    const whitelistResult = {
      url: urlStr,
      score: 0,
      status: "SAFE",
      detection: "Whitelist (Local)",
      timestamp: new Date().toISOString(),
      reasons: ["Trusted Domain Whitelist"],
      localScore: 0,
      serverScore: 0,
      serverConnected: isServerOnline,
      stage: "final",
      metadata: null
    };

    await chrome.storage.local.set({ [`tab_${tabId}`]: whitelistResult });
    await saveLog(whitelistResult);
    updateBadge(tabId, 0, "SAFE"); // Show green SAFE / 0% badge
    broadcastState(tabId, whitelistResult);

    // Asynchronously fetch metadata in the background if server AI is enabled
    if (activeSettings.serverAiEnabled) {
      (async () => {
        try {
          const serverResult = await runServerInference(urlStr, activeSettings.serverUrl);
          if (serverResult && serverResult.metadata) {
            whitelistResult.metadata = serverResult.metadata;
            whitelistResult.serverConnected = true;
            isServerOnline = true;
            await chrome.storage.local.set({ serverOnline: true });
            
            await saveLog(whitelistResult);
            await chrome.storage.local.set({ [`tab_${tabId}`]: whitelistResult });
            broadcastState(tabId, whitelistResult);
          }
        } catch (e) {
          console.warn("PhishingGuard: Whitelist background metadata fetch failed:", e);
        }
      })();
    }
    return;
  }

  // STAGE 1: Execute Local Heuristics Instantly
  let heuristicResult = { score: 0, reasons: [] };
  if (activeSettings.localHeuristicsEnabled) {
    heuristicResult = runLocalHeuristics(urlStr);
  }

  let localScore = heuristicResult.score;
  let localStatus = "SAFE";
  if (localScore >= 60) {
    localStatus = "DANGEROUS";
  } else if (localScore >= 40) {
    localStatus = "WARNING";
  }

  // Store intermediate state and notify UI
  const localScanState = {
    url: urlStr,
    score: localScore,
    status: localStatus,
    detection: "Local Heuristics",
    timestamp: new Date().toISOString(),
    reasons: ["Local scan complete. Server verifying..."],
    localScore: localScore,
    serverScore: null,
    serverConnected: isServerOnline,
    stage: "preliminary"
  };

  await chrome.storage.local.set({ [`tab_${tabId}`]: localScanState });
  updateBadge(tabId, localScore, localStatus);
  broadcastState(tabId, localScanState);

  // If local scan flags it as DANGEROUS, block it instantly
  if (localStatus === "DANGEROUS" && activeSettings.autoBlockEnabled) {
    console.log(`PhishingGuard: Fast Block (Heuristics) triggered for ${urlStr}`);
    const blockUrl = chrome.runtime.getURL(`block.html?url=${encodeURIComponent(urlStr)}&tabId=${tabId}`);
    chrome.tabs.update(tabId, { url: blockUrl });
    await saveLog(localScanState);
    return;
  }

  // STAGE 2: Query Server XGBoost asynchronously in the background
  if (activeSettings.serverAiEnabled) {
    localScanState.stage = "server_checking";
    await chrome.storage.local.set({ [`tab_${tabId}`]: localScanState });
    broadcastState(tabId, localScanState);

    const serverResult = await runServerInference(urlStr, activeSettings.serverUrl);
    
    let finalScore = localScore;
    let serverScore = null;
    let isServerConnected = false;
    let finalReasons = [];
    let method = "";
    let metadata = null;

    if (serverResult !== null) {
      serverScore = serverResult.score;
      isServerConnected = true;
      isServerOnline = true;
      await chrome.storage.local.set({ serverOnline: true });
      finalReasons = serverResult.reasons;
      metadata = serverResult.metadata || null;
      
      // Since local ML is removed, server score completely overrides heuristics when online
      finalScore = serverScore;
      method = "Server AI (XGBoost)";
    } else {
      // Server timed out/failed -> Fallback to local heuristics
      isServerConnected = false;
      isServerOnline = false;
      await chrome.storage.local.set({ serverOnline: false });
      finalScore = localScore;
      finalReasons = ["Server connection failed. Offline Heuristics fallback."];
      method = "Local Heuristics (Offline)";
    }

    let finalStatus = "SAFE";
    if (finalScore >= 60) {
      finalStatus = "DANGEROUS";
    } else if (!isServerConnected || finalScore >= 40) {
      // If server is not connected (offline) and score is below 60, show yellow/WARNING
      finalStatus = "WARNING";
    }

    const finalScanState = {
      url: urlStr,
      score: finalScore,
      status: finalStatus,
      detection: method,
      timestamp: new Date().toISOString(),
      reasons: finalReasons,
      localScore: localScore,
      serverScore: serverScore,
      serverConnected: isServerConnected,
      stage: "final",
      metadata: metadata
    };

    await chrome.storage.local.set({ [`tab_${tabId}`]: finalScanState });
    await saveLog(finalScanState);
    updateBadge(tabId, finalScore, finalStatus);
    broadcastState(tabId, finalScanState);

    // Block or warn page based on final score
    if (finalStatus === "DANGEROUS" && activeSettings.autoBlockEnabled) {
      console.log(`PhishingGuard: Delayed Block (Server) triggered for ${urlStr}`);
      const blockUrl = chrome.runtime.getURL(`block.html?url=${encodeURIComponent(urlStr)}&tabId=${tabId}`);
      chrome.tabs.update(tabId, { url: blockUrl });
    } else if (finalStatus === "WARNING") {
      try {
        if (!isServerConnected) {
          chrome.tabs.sendMessage(tabId, { action: "showOfflineCautionBanner" }, () => {
            if (chrome.runtime.lastError) {}
          });
        } else {
          chrome.tabs.sendMessage(tabId, { 
            action: "showWarningBanner", 
            score: finalScore 
          }, (response) => {
            if (chrome.runtime.lastError) {}
          });
        }
      } catch (e) {}
    }
  } else {
    // Server AI is toggled off, seal local results as final
    localScanState.stage = "final";
    localScanState.reasons = heuristicResult.reasons;
    localScanState.detection = "Local Heuristics";
    
    // User request: If server is disabled and not whitelisted, show yellow/WARNING
    localScanState.status = "WARNING";
    if (localScore >= 60) {
      localScanState.status = "DANGEROUS";
    }
    
    await chrome.storage.local.set({ [`tab_${tabId}`]: localScanState });
    await saveLog(localScanState);
    updateBadge(tabId, localScore, localScanState.status);
    broadcastState(tabId, localScanState);
    
    // Trigger offline caution banner for untrusted sites
    try {
      chrome.tabs.sendMessage(tabId, { action: "showOfflineCautionBanner" }, () => {
        if (chrome.runtime.lastError) {}
      });
    } catch (e) {}
  }
}

// Update Chrome extension badge & icon color
function updateBadge(tabId, score, status) {
  let badgeText = "";
  let badgeColor = "#22c55e";
  
  if (status === "DANGEROUS") {
    badgeText = score !== null ? `${score}%` : "BLOCK";
    badgeColor = "#ef4444";
  } else if (status === "WARNING") {
    badgeText = score !== null ? `${score}%` : "WARN";
    badgeColor = "#facc15";
    chrome.action.setBadgeTextColor({ color: "#000000" });
  } else {
    badgeText = score !== null ? `${score}%` : "SAFE";
    badgeColor = "#22c55e";
    chrome.action.setBadgeTextColor({ color: "#ffffff" });
  }

  chrome.action.setBadgeText({ tabId: tabId, text: badgeText });
  chrome.action.setBadgeBackgroundColor({ tabId: tabId, color: badgeColor });
}

// Save scan results to logs list in local storage
async function saveLog(logEntry) {
  const result = await chrome.storage.local.get('logs');
  let logsList = result.logs || [];
  
  logsList = logsList.filter(item => item.url !== logEntry.url);
  logsList.unshift(logEntry);
  
  if (logsList.length > 500) {
    logsList = logsList.slice(0, 500);
  }
  
  await chrome.storage.local.set({ logs: logsList });
}

// Update log exit timestamp when user navigates away or closes tab
async function updateLogExitTime(urlStr, exitTime) {
  const result = await chrome.storage.local.get('logs');
  let logsList = result.logs || [];
  let updated = false;
  
  for (let i = 0; i < logsList.length; i++) {
    if (logsList[i].url === urlStr && !logsList[i].exitedTime) {
      logsList[i].exitedTime = exitTime;
      updated = true;
      break;
    }
  }
  
  if (updated) {
    await chrome.storage.local.set({ logs: logsList });
    chrome.runtime.sendMessage({ action: "logsUpdated" }).catch(() => {});
  }
}

// Event Listeners
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status === 'loading' && tab.url) {
    // Record exit time for previous page in this tab
    if (activeTabUrls[tabId] && activeTabUrls[tabId].url !== tab.url) {
      const prevUrl = activeTabUrls[tabId].url;
      const exitTime = new Date().toISOString();
      updateLogExitTime(prevUrl, exitTime).catch(e => {});
    }
    
    // Set active tab URL tracking state
    activeTabUrls[tabId] = {
      url: tab.url,
      startTime: new Date().toISOString()
    };
    
    analyzeUrl(tab.url, tabId);
  }
});

chrome.tabs.onRemoved.addListener((tabId) => {
  if (activeTabUrls[tabId]) {
    const prevUrl = activeTabUrls[tabId].url;
    const exitTime = new Date().toISOString();
    updateLogExitTime(prevUrl, exitTime).catch(e => {});
    delete activeTabUrls[tabId];
  }
});

// Communication messages from Popup or Blocker Page
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "verifyConnection") {
    checkServerConnection(1, 0).then((online) => {
      sendResponse({ serverOnline: online });
    });
    return true;
  }

  if (request.action === "checkPageStatus") {
    const tabId = sender.tab ? sender.tab.id : null;
    if (tabId) {
      chrome.storage.local.get(`tab_${tabId}`, (res) => {
        const result = res[`tab_${tabId}`];
        if (result && result.stage === "final") {
          if (result.status === "WARNING") {
            if (!result.serverConnected && result.detection !== "Whitelist (Local)") {
              sendResponse({ status: "offline_caution" });
            } else {
              sendResponse({ status: "warning", score: result.score });
            }
          } else {
            sendResponse({ status: "none" });
          }
        } else {
          sendResponse({ status: "none" });
        }
      });
      return true;
    }
  }

  if (request.action === "getTabAnalysis") {
    const tabId = request.tabId;
    chrome.storage.local.get(`tab_${tabId}`, (res) => {
      sendResponse({ data: res[`tab_${tabId}`] || null });
    });
    return true;
  }
  
  if (request.action === "bypassBlock") {
    const url = request.url;
    const tabId = parseInt(request.tabId);
    if (url) {
      bypassedUrls.add(url);
      console.log(`PhishingGuard: User bypassed block for ${url}`);
      chrome.tabs.update(tabId, { url: url }, () => {
        setTimeout(() => {
          updateBadge(tabId, 0, "SAFE");
        }, 800);
      });
      sendResponse({ status: "success" });
    }
    return true;
  }

  if (request.action === "reAnalyze") {
    const url = request.url;
    const tabId = request.tabId;
    
    chrome.storage.local.get('settings', (res) => {
      const settings = res.settings || DEFAULT_SETTINGS;
      if (settings.serverAiEnabled) {
        // Run full server connection check if server AI is active
        checkServerConnection(3, 1000).then(() => {
          analyzeUrl(url, tabId).then(() => {
            chrome.storage.local.get(`tab_${tabId}`, (resTab) => {
              sendResponse({ data: resTab[`tab_${tabId}`] || null });
            });
          });
        });
      } else {
        // Skip connection checks completely and run local check instantly
        analyzeUrl(url, tabId).then(() => {
          chrome.storage.local.get(`tab_${tabId}`, (resTab) => {
            sendResponse({ data: resTab[`tab_${tabId}`] || null });
          });
        });
      }
    });
    return true;
  }
  
  if (request.action === "checkServerStatus") {
    chrome.storage.local.get('serverOnline', (res) => {
      sendResponse({ serverOnline: !!res.serverOnline });
    });
    return true;
  }
});
