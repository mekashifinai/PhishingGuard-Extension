// PhishingGuard Block Page logic

document.addEventListener('DOMContentLoaded', () => {
  const urlDisplay = document.getElementById('blockedUrlDisplay');
  const goBackBtn = document.getElementById('goBackBtn');
  const bypassBtn = document.getElementById('bypassBtn');

  // Parse query parameters
  const params = new URLSearchParams(window.location.search);
  const blockedUrl = params.get('url') || '';
  const tabId = params.get('tabId') || '';

  // Display the blocked URL
  if (blockedUrl) {
    urlDisplay.innerText = blockedUrl;
  } else {
    urlDisplay.innerText = "Unknown URL";
  }

  // Go Back Action
  goBackBtn.addEventListener('click', () => {
    // If we have history to go back to, use it
    if (document.referrer && !document.referrer.includes(chrome.runtime.id)) {
      history.back();
    } else {
      // Fallback: Redirect to a safe tab page or close
      window.location.href = "https://www.google.com";
    }
  });

  // Bypass and Continue Action
  bypassBtn.addEventListener('click', () => {
    if (confirm("WARNING: Phishing sites can steal your passwords, credit cards, or personal details. Are you absolutely sure you want to proceed?")) {
      chrome.runtime.sendMessage({
        action: "bypassBlock",
        url: blockedUrl,
        tabId: tabId
      }, (response) => {
        // Tab will be redirected back to the original page by the background script,
        // which has added it to bypassedUrls list so it won't block again.
        if (chrome.runtime.lastError) {
          console.error("Error bypassing block:", chrome.runtime.lastError);
          // Fallback if background channel fails: redirect directly
          window.location.href = blockedUrl;
        }
      });
    }
  });
});
